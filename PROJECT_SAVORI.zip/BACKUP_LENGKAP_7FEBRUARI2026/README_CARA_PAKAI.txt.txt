=== BACKUP PROJECT ===
Tanggal: 7 Februari 2026
Nama Project: Savori

ISI FOLDER:
1. SOURCE_CODE = semua file website (PHP, HTML, CSS, JS)
2. savori_db.sql = backup database MySQL

CARA PAKAI:
1. Extract ZIP ini di folder htdocs (C:\xampp\htdocs\)
2. Rename folder jadi: "Savori"
3. Import database (lihat cara di bawah)
4. Buka browser: http://localhost/Savori

CARA IMPORT DATABASE MYSQL:
1. Buka phpMyAdmin (http://localhost/phpmyadmin)
2. Buat database baru dengan nama: "savori_db"
3. Klik database baru tersebut
4. Klik tab "Import"
5. Pilih file "savori_db.sql"
6. Klik "Go"
7. Selesai

INFO LOGIN DEFAULT:
Username: ken
Password: 222222

KONTAK DEVELOPER:
Nama: Savori team
Email: sashaellamagdalene@gmail.com
No HP: 087700250980