<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../models/Recommendation.php';
require_once '../models/Drink.php';
require_once '../models/Stock.php';

$database = new Database();
$db = $database->getConnection();
$recommendation = new Recommendation($db);
$drink = new Drink($db);
$stock = new Stock($db);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->mood) && isset($data->weather) && isset($data->time_of_day) && isset($_SESSION['user_id'])) {
    $mood = $data->mood;
    $weather = $data->weather;
    $time_of_day = $data->time_of_day;
    $user_id = $_SESSION['user_id'];
    
    // Get today's date
    $today = date('Y-m-d');
    
    // Get available drinks for today
    $available_drinks = $stock->getAvailableDrinks($today);
    
    if(empty($available_drinks)) {
        echo json_encode([
            'success' => false,
            'message' => 'Maaf, tidak ada stok kopi tersedia hari ini'
        ]);
        exit;
    }
    
    // Algorithm for recommendation based on mood, weather, and time
    $recommended_drinks = [];
    
    foreach($available_drinks as $drink_id) {
        $drink->id = $drink_id;
        $drink_data = $drink->getDrinkById();
        
        if($drink_data) {
            $score = 0;
            
            // Mood-based scoring
            if($mood == 'energik' && $drink_data['caffeine_level'] == 'High') $score += 3;
            if($mood == 'santai' && $drink_data['caffeine_level'] == 'Low') $score += 3;
            if($mood == 'stres' && $drink_data['type'] == 'Latte') $score += 2;
            
            // Weather-based scoring
            if($weather == 'panas' && $drink_data['name'] == 'Cold Brew') $score += 4;
            if($weather == 'dingin' && $drink_data['type'] == 'Mocha') $score += 3;
            
            // Time-based scoring
            if($time_of_day == 'pagi' && $drink_data['caffeine_level'] == 'High') $score += 2;
            if($time_of_day == 'malam' && $drink_data['caffeine_level'] == 'Low') $score += 2;
            
            // Add popularity score
            $score += ($drink_data['popularity_score'] / 100);
            
            $recommended_drinks[] = [
                'drink' => $drink_data,
                'score' => $score,
                'match_reason' => $this->getMatchReason($mood, $weather, $time_of_day, $drink_data)
            ];
        }
    }
    
    // Sort by score
    usort($recommended_drinks, function($a, $b) {
        return $b['score'] <=> $a['score'];
    });
    
    // Save the top recommendation
    if(!empty($recommended_drinks)) {
        $recommendation->user_id = $user_id;
        $recommendation->drink_id = $recommended_drinks[0]['drink']['id'];
        $recommendation->mood = $mood;
        $recommendation->weather = $weather;
        $recommendation->time_of_day = $time_of_day;
        $recommendation->create();
    }
    
    echo json_encode([
        'success' => true,
        'recommendations' => array_slice($recommended_drinks, 0, 5),
        'total_available' => count($available_drinks)
    ]);
    
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Data tidak lengkap'
    ]);
}

function getMatchReason($mood, $weather, $time, $drink) {
    $reasons = [];
    
    if($mood == 'energik' && $drink['caffeine_level'] == 'High') {
        $reasons[] = "Cocok untuk mood energik karena kadar kafein tinggi";
    }
    
    if($weather == 'panas' && in_array($drink['name'], ['Cold Brew', 'Frappuccino'])) {
        $reasons[] = "Sempurna untuk cuaca panas";
    }
    
    return !empty($reasons) ? implode('. ', $reasons) : "Rekomendasi berdasarkan preferensi Anda";
}
?>