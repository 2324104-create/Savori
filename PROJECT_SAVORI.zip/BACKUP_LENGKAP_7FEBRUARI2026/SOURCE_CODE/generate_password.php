<?php
echo password_hash('admin123', PASSWORD_DEFAULT);
// Copy output dan paste ke SQL di atas
?>